<?php  
namespace Concrete\Package\Proevents\Controller\Tools\ProEventList;

use Loader;
use Page;
use Block;
use Concrete\Core\Controller\Controller;

class Rss extends Controller
{
    protected $viewPath = '/tools/pro_event_list/rss';

    public function view()
    {

    }
}