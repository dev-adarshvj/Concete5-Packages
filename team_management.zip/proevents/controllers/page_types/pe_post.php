<?php  
namespace Concrete\Package\Proevents\Controller\PageType;

use \Concrete\Core\Page\Type\Type as PageTypeController;
use \Concrete\Core\Page\Controller\PageController;
use Loader;
use Cache;
use Area;
use Page;

class PePost extends PageController
{


}