<?php  
namespace Concrete\Package\Proevents\Controller\Ajax\ProEventList;

use Loader;
use Page;
use Block;
use Concrete\Core\Controller\Controller;

class ListAjax extends Controller
{
    protected $viewPath = '/ajax/pro_event_list/list_ajax';
    
    public function view()
    {

    }

}