<?php  
namespace Concrete\Package\Proevents\Controller\Ajax\ProEventList;

use Loader;
use Page;
use Block;
use Concrete\Core\Controller\Controller;

class CalendarDynamic extends Controller
{
    protected $viewPath = '/ajax/pro_event_list/calendar_dynamic';
    public function view()
    {

    }

}