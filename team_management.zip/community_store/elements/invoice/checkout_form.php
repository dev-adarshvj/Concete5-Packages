<?php defined('C5_EXECUTE') or die("Access Denied.");
extract($vars);
?>

<p><?= t("An invoice will be sent to you upon ordering")?></p>
