# Introduction

This section covers the configuration steps for common setups with Community Store.

The steps described in this section are to give high-level summaries of some of the ways Community Store and concrete5 can be configured together, allowing for custom eCommerce scenarios. 
  
 
