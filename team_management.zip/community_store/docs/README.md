---
home: true
heroImage: logo.png
actionText: Get Started →
actionLink: /user-guide/
tagline: An open, free and community developed eCommerce system for concrete5
features:
- title: Powerful eCommerce 
  details: Product and checkout options suiting a wide range of digital and traditional eCommerce requirements
- title: Highly Customizable
  details: Style, override and configure blocks, pages and other store elements with freedom
- title: Open Source & Free 
  details: MIT licenced and community supported, developed for concrete5 fans, by concrete5 fans

footer: MIT Licensed
---
