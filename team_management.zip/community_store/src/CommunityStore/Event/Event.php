<?php

namespace Concrete\Package\CommunityStore\Src\CommunityStore\Event;

use Symfony\Component\EventDispatcher\GenericEvent;

abstract class Event extends GenericEvent {


}